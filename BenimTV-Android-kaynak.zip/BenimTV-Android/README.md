# Benim TV — başlangıç Android projesi

Bu, telefon ve Android TV için hazırlanmış ilk kaynak kod taslağıdır. Uygulama hesap istemez; kullanıcı kendi sahip olduğu veya yayıncının ücretsiz ve yasal olarak sunduğu M3U bağlantısını ekler.

## APK oluşturma
1. Bilgisayara Android Studio'nun güncel sürümünü kurun.
2. Bu klasörü Android Studio'da **Open** ile açın.
3. Gradle eşitlemesi tamamlanınca **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin.
4. APK, `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

## Notlar
- Bu kaynak paketi APK değildir; Android Studio ile derlenmesi gerekir.
- Uygulama herhangi bir ücretli/izinsiz kanal listesi içermez.
- Bazı yayınlar DRM, bölge kısıtlaması veya yayıncı erişim şartları nedeniyle oynatılamayabilir.
- Bu ilk sürüm temel M3U yükleme ve oynatmayı içerir. Favoriler, kategori filtreleri, arama, daha gelişmiş TV kumandası odağı ve hata yönetimi sonraki sürümde eklenebilir.
