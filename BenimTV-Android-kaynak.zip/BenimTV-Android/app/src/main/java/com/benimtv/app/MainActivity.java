package com.benimtv.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.TextUtils;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(7,20,38), panel = Color.rgb(14,35,61), blue = Color.rgb(45,125,238);
    private ExoPlayer player;
    private PlayerView playerView;
    private EditText playlistUrl;
    private LinearLayout channelList;
    private TextView status;
    private final ArrayList<Channel> channels = new ArrayList<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    static class Channel {
        String name, url, group;
        Channel(String n, String u, String g) { name=n; url=u; group=g; }
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().getDecorView().setBackgroundColor(bg);
        player = new ExoPlayer.Builder(this).build();
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView label(String value, int size) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(Color.WHITE);
        t.setTextSize(size); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(18)); scroll.addView(page);
        TextView title = label("BENİM TV", 26); title.setTypeface(null, Typeface.BOLD); title.setTextColor(0xff69a7ff);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView subtitle = label("Canlı yayınlar • Türkçe ve Kürtçe", 14);
        subtitle.setTextColor(0xffb7c9df); page.addView(subtitle);
        playerView = new PlayerView(this); playerView.setPlayer(player); playerView.setUseController(true);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(220)); pp.setMargins(0, dp(14), 0, dp(14));
        page.addView(playerView, pp);
        playlistUrl = new EditText(this); playlistUrl.setSingleLine(true);
        playlistUrl.setHint("M3U bağlantısını buraya yapıştır"); playlistUrl.setTextColor(Color.WHITE);
        playlistUrl.setHintTextColor(0xff9aacc2); playlistUrl.setTextSize(14);
        playlistUrl.setPadding(dp(12), 0, dp(12), 0); playlistUrl.setBackgroundColor(panel);
        page.addView(playlistUrl, new LinearLayout.LayoutParams(-1, dp(50)));
        Button load = new Button(this); load.setText("M3U LİSTESİNİ YÜKLE");
        load.setOnClickListener(v -> loadPlaylist(playlistUrl.getText().toString().trim()));
        page.addView(load, new LinearLayout.LayoutParams(-1, dp(52)));
        status = label("Yayın listesi ekleyerek başlayın.", 13); status.setTextColor(0xffb7c9df);
        page.addView(status);
        TextView heading = label("KANALLAR", 18); heading.setTypeface(null, Typeface.BOLD);
        page.addView(heading, new LinearLayout.LayoutParams(-1, dp(48)));
        channelList = new LinearLayout(this); channelList.setOrientation(LinearLayout.VERTICAL);
        page.addView(channelList);
        setContentView(scroll);
    }

    private void loadPlaylist(String address) {
        if (address.isEmpty()) { status.setText("Önce M3U bağlantısını girin."); return; }
        status.setText("Liste yükleniyor…");
        executor.execute(() -> {
            ArrayList<Channel> found = new ArrayList<>();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(new URL(address).openStream(), "UTF-8"))) {
                String line, name = "İsimsiz kanal", group = "Diğer";
                while ((line = r.readLine()) != null) {
                    line = line.trim();
                    if (line.startsWith("#EXTINF")) {
                        int comma = line.lastIndexOf(',');
                        name = comma >= 0 ? line.substring(comma+1).trim() : "İsimsiz kanal";
                        int g = line.indexOf("group-title=\"");
                        if (g >= 0) { int end = line.indexOf('"', g+13); if (end > g) group = line.substring(g+13, end); }
                    } else if (!line.isEmpty() && !line.startsWith("#") && (line.startsWith("http://") || line.startsWith("https://"))) {
                        found.add(new Channel(name, line, group)); name = "İsimsiz kanal"; group = "Diğer";
                    }
                }
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Liste açılamadı. Bağlantıyı ve interneti kontrol edin."));
                return;
            }
            runOnUiThread(() -> {
                channels.clear(); channels.addAll(found); channelList.removeAllViews();
                for (Channel c : channels) addChannel(c);
                status.setText(found.size() + " kanal yüklendi.");
            });
        });
    }

    private void addChannel(Channel c) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(14), dp(9), dp(14), dp(9)); row.setBackgroundColor(panel);
        TextView n = label(c.name, 16); n.setTypeface(null, Typeface.BOLD);
        TextView g = label(c.group, 12); g.setTextColor(0xff9db5d1);
        row.addView(n); row.addView(g);
        row.setFocusable(true); row.setClickable(true);
        row.setOnClickListener(v -> {
            player.setMediaItem(MediaItem.fromUri(c.url)); player.prepare(); player.play();
            status.setText("Oynatılıyor: " + c.name);
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(4), 0, dp(4));
        channelList.addView(row, lp);
    }

    @Override protected void onStop() { super.onStop(); if (player != null) player.pause(); }
    @Override protected void onDestroy() {
        super.onDestroy(); if (player != null) player.release(); executor.shutdownNow();
    }
}
